// js/chat.js — Text chat system (global + DM)
const Chat = {
  currentTab: 'global',
  tabs: { global: [] },   // tabId -> messages[]
  dmPartners: {},          // tabId -> { id, name }
  collapsed: false,
  socket: null,

  init(socket) {
    this.socket = socket;
    const input = document.getElementById('chat-input');
    input.addEventListener('focus', () => { Input.chatFocused = true; });
    input.addEventListener('blur', () => { Input.chatFocused = false; });

    socket.on('chatMessage', msg => {
      this.addMessage('global', msg.from, msg.fromId, msg.text, false);
    });

    socket.on('dmMessage', msg => {
      const partnerId = msg.fromId === Game.myId ? msg.to : msg.fromId;
      const partnerName = msg.fromId === Game.myId ? (this.dmPartners[partnerId]?.name || 'DM') : msg.from;
      if (!this.tabs[partnerId]) this.openDM(partnerId, partnerName);
      this.addMessage(partnerId, msg.from, msg.fromId, msg.text, true);
    });
  },

  addMessage(tabId, senderName, senderId, text, isDM) {
    if (!this.tabs[tabId]) this.tabs[tabId] = [];
    this.tabs[tabId].push({ senderName, senderId, text, isDM, ts: Date.now() });

    if (this.currentTab === tabId) {
      this._renderMessage(senderName, senderId, text, isDM);
      this._scrollToBottom();
    } else {
      // Mark tab as having unread
      const tabBtn = document.querySelector(`[data-tab="${tabId}"]`);
      if (tabBtn && !tabBtn.querySelector('.unread')) {
        const dot = document.createElement('span');
        dot.className = 'unread';
        tabBtn.appendChild(dot);
      }
    }

    if (this.collapsed) this._flashToggle();
  },

  _renderMessage(senderName, senderId, text, isDM) {
    const msgs = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = 'chat-msg' + (isDM ? ' dm' : '');
    const isMe = senderId === Game.myId;
    div.innerHTML = `<span class="sender" onclick="Chat.openDM('${senderId}','${senderName}')">${senderName}:</span><span class="msg-text"> ${this._escape(text)}</span>`;
    msgs.appendChild(div);
  },

  _escape(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  },

  _scrollToBottom() {
    const msgs = document.getElementById('chat-messages');
    msgs.scrollTop = msgs.scrollHeight;
  },

  _flashToggle() {
    const btn = document.getElementById('chat-toggle');
    btn.style.color = '#ffcc00';
    setTimeout(() => btn.style.color = '', 1000);
  },

  switchTab(tabId) {
    this.currentTab = tabId;
    document.querySelectorAll('.chat-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tabId));
    // Remove unread dot
    const tabBtn = document.querySelector(`[data-tab="${tabId}"]`);
    if (tabBtn) tabBtn.querySelector('.unread')?.remove();
    // Re-render messages
    const msgs = document.getElementById('chat-messages');
    msgs.innerHTML = '';
    (this.tabs[tabId] || []).forEach(m => this._renderMessage(m.senderName, m.senderId, m.text, m.isDM));
    this._scrollToBottom();
  },

  openDM(partnerId, partnerName) {
    if (partnerId === Game.myId) return;
    if (!this.tabs[partnerId]) {
      this.tabs[partnerId] = [];
      this.dmPartners[partnerId] = { id: partnerId, name: partnerName };
      // Add DM tab button
      const dmTabs = document.getElementById('dm-tabs');
      const btn = document.createElement('button');
      btn.className = 'chat-tab';
      btn.dataset.tab = partnerId;
      btn.innerHTML = `${partnerName} <span class="close-tab" onclick="Chat.closeDM('${partnerId}',event)">✕</span>`;
      btn.onclick = () => this.switchTab(partnerId);
      dmTabs.appendChild(btn);
    }
    this.switchTab(partnerId);
    // Expand chat if collapsed
    if (this.collapsed) this.open();
    document.getElementById('chat-input').focus();
  },

  closeDM(partnerId, event) {
    event.stopPropagation();
    const tabBtn = document.querySelector(`[data-tab="${partnerId}"]`);
    tabBtn?.remove();
    delete this.tabs[partnerId];
    delete this.dmPartners[partnerId];
    if (this.currentTab === partnerId) this.switchTab('global');
  },

  send() {
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text || !this.socket) { input.blur(); return; }
    const isDM = this.currentTab !== 'global';
    const targetId = isDM ? this.currentTab : null;
    this.socket.emit('chatMessage', { text, targetId });
    if (isDM) {
      this.addMessage(this.currentTab, 'You', Game.myId, text, true);
    }
    input.value = '';
    input.blur();
    Input.chatFocused = false;
  },

  open() {
    this.collapsed = false;
    document.getElementById('chat-container').classList.remove('collapsed');
    document.getElementById('chat-input').focus();
  },

  close() {
    document.getElementById('chat-input').blur();
    Input.chatFocused = false;
  },

  addSystemMessage(text) {
    const msgs = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = 'chat-msg system';
    div.textContent = text;
    msgs.appendChild(div);
    this._scrollToBottom();
  },
};

function switchTab(id) { Chat.switchTab(id); }
function sendChat() { Chat.send(); }
function toggleChat() {
  Chat.collapsed = !Chat.collapsed;
  document.getElementById('chat-container').classList.toggle('collapsed', Chat.collapsed);
}
