// js/input.js — Keyboard and mouse input
const Input = {
  keys: {},
  mouse: { x: 0, y: 0, down: false },
  chatFocused: false,

  init() {
    document.addEventListener('keydown', e => this._onKeyDown(e));
    document.addEventListener('keyup', e => { this.keys[e.code] = false; });
    const c = document.getElementById('gameCanvas');
    c.addEventListener('mousemove', e => {
      const r = c.getBoundingClientRect();
      this.mouse.x = e.clientX - r.left;
      this.mouse.y = e.clientY - r.top;
    });
    c.addEventListener('mousedown', () => { this.mouse.down = true; });
    c.addEventListener('mouseup',   () => { this.mouse.down = false; });
    c.addEventListener('contextmenu', e => e.preventDefault());
  },

  _onKeyDown(e) {
    this.keys[e.code] = true;

    // Chat: T to open, Enter to send, Escape to close
    if (e.code === 'KeyT' && !this.chatFocused) {
      e.preventDefault();
      Chat.open();
      return;
    }
    if (e.code === 'Enter' && this.chatFocused) {
      Chat.send();
      return;
    }
    if (e.code === 'Escape') {
      e.preventDefault();
      if (this.chatFocused) {
        Chat.close();
      } else {
        toggleEscMenu();
      }
      return;
    }

    if (this.chatFocused) return; // don't process game keys while chatting

    if (e.code === 'KeyR') Game.reload();
    if (e.code === 'KeyE') Game.useItem();
    if (e.code === 'KeyF') Game.pickupNearby();
    if (e.code === 'KeyG') Game.dropItem();
  },
};

let escMenuOpen = false;
function toggleEscMenu() {
  escMenuOpen = !escMenuOpen;
  const menu = document.getElementById('esc-menu');
  menu.style.display = escMenuOpen ? 'flex' : 'none';
  if (escMenuOpen) updateEscPlayerList();
}
function closeEscMenu() {
  escMenuOpen = false;
  document.getElementById('esc-menu').style.display = 'none';
}

function updateEscPlayerList() {
  const list = document.getElementById('esc-player-list');
  list.innerHTML = '';
  if (!Game.playerList) return;
  Game.playerList.forEach(p => {
    const row = document.createElement('div');
    row.className = 'esc-player-row';
    const isYou = p.id === Game.myId;
    const skin = SKINS[p.skin] || SKINS[0];

    row.innerHTML = `
      <div class="esc-player-skin" style="background:${skin.color}"></div>
      <span class="esc-player-name${isYou ? ' you' : ''}">${p.name}${isYou ? ' (YOU)' : ''}</span>
      ${!isYou ? `
        <button class="esc-btn" onclick="Voice.toggleMutePeer('${p.id}', this)">MUTE</button>
        <button class="esc-btn" onclick="Chat.openDM('${p.id}','${p.name}');closeEscMenu()">DM</button>
      ` : ''}
    `;
    list.appendChild(row);
  });
}
