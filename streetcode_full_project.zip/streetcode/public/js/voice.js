// js/voice.js — WebRTC proximity/global voice chat
const Voice = {
  enabled: false,
  muted: false,
  localStream: null,
  peers: {},      // peerId -> { pc, audioEl, muted }
  socket: null,

  init(socket) {
    this.socket = socket;

    // WebRTC signaling via Socket.io
    socket.on('voiceOffer', async ({ from, offer }) => {
      if (!this.enabled) return;
      await this._handleOffer(from, offer);
    });

    socket.on('voiceAnswer', async ({ from, answer }) => {
      const peer = this.peers[from];
      if (peer?.pc) await peer.pc.setRemoteDescription(answer);
    });

    socket.on('voiceCandidate', async ({ from, candidate }) => {
      const peer = this.peers[from];
      if (peer?.pc) await peer.pc.addIceCandidate(candidate).catch(() => {});
    });

    socket.on('playerJoined', ({ id }) => {
      if (this.enabled) this._callPeer(id);
    });

    socket.on('playerLeft', ({ id }) => {
      this._closePeer(id);
    });
  },

  async enable() {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      this.enabled = true;
      document.getElementById('voice-btn').textContent = 'MUTE';
      document.getElementById('voice-btn').classList.add('active');
      document.getElementById('voice-label').textContent = 'VOICE ON';
      // Call all existing players
      if (Game.playerList) {
        Game.playerList.forEach(p => {
          if (p.id !== Game.myId) this._callPeer(p.id);
        });
      }
    } catch (err) {
      alert('Microphone access denied. Voice chat unavailable.');
      console.error(err);
    }
  },

  disable() {
    if (this.localStream) {
      this.localStream.getTracks().forEach(t => t.stop());
      this.localStream = null;
    }
    Object.keys(this.peers).forEach(id => this._closePeer(id));
    this.enabled = false;
    document.getElementById('voice-btn').textContent = 'ENABLE VOICE';
    document.getElementById('voice-btn').classList.remove('active', 'speaking');
    document.getElementById('voice-label').textContent = 'VOICE OFF';
  },

  toggleMute() {
    if (!this.localStream) return;
    this.muted = !this.muted;
    this.localStream.getAudioTracks().forEach(t => t.enabled = !this.muted);
    const btn = document.getElementById('voice-btn');
    btn.textContent = this.muted ? 'UNMUTE' : 'MUTE';
    document.getElementById('voice-label').textContent = this.muted ? 'MUTED' : 'VOICE ON';
  },

  toggleMutePeer(peerId, btn) {
    const peer = this.peers[peerId];
    if (!peer) return;
    peer.muted = !peer.muted;
    if (peer.audioEl) peer.audioEl.muted = peer.muted;
    btn.textContent = peer.muted ? 'UNMUTE' : 'MUTE';
    btn.classList.toggle('muted', peer.muted);
  },

  async _callPeer(peerId) {
    if (this.peers[peerId] || !this.localStream) return;
    const pc = this._createPC(peerId);
    this.peers[peerId] = { pc, audioEl: null, muted: false };
    this.localStream.getTracks().forEach(t => pc.addTrack(t, this.localStream));
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    this.socket.emit('voiceOffer', { to: peerId, offer });
  },

  async _handleOffer(fromId, offer) {
    if (this.peers[fromId]) return;
    const pc = this._createPC(fromId);
    this.peers[fromId] = { pc, audioEl: null, muted: false };
    if (this.localStream) this.localStream.getTracks().forEach(t => pc.addTrack(t, this.localStream));
    await pc.setRemoteDescription(offer);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    this.socket.emit('voiceAnswer', { to: fromId, answer });
  },

  _createPC(peerId) {
    const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });

    pc.onicecandidate = e => {
      if (e.candidate) this.socket.emit('voiceCandidate', { to: peerId, candidate: e.candidate });
    };

    pc.ontrack = e => {
      const audioEl = new Audio();
      audioEl.srcObject = e.streams[0];
      audioEl.play().catch(() => {});
      if (this.peers[peerId]) {
        this.peers[peerId].audioEl = audioEl;
        audioEl.muted = this.peers[peerId].muted;
      }
      this._updateVoicePeersUI();
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        this._closePeer(peerId);
      }
    };
    return pc;
  },

  _closePeer(peerId) {
    const peer = this.peers[peerId];
    if (!peer) return;
    if (peer.pc) peer.pc.close();
    if (peer.audioEl) { peer.audioEl.pause(); peer.audioEl.srcObject = null; }
    delete this.peers[peerId];
    this._updateVoicePeersUI();
  },

  _updateVoicePeersUI() {
    const container = document.getElementById('voice-peers');
    container.innerHTML = '';
    Object.entries(this.peers).forEach(([id, peer]) => {
      const player = Game.playerList?.find(p => p.id === id);
      const name = player?.name || id.slice(0, 6);
      const div = document.createElement('div');
      div.className = 'voice-peer';
      div.id = `vp-${id}`;
      div.innerHTML = `🎤 ${name} <button class="voice-peer-mute" onclick="Voice.toggleMutePeer('${id}',this)">${peer.muted ? '🔇' : '🔊'}</button>`;
      container.appendChild(div);
    });
  },
};

function toggleVoice() {
  if (!Voice.enabled) Voice.enable();
  else if (!Voice.muted) Voice.toggleMute();
  else { Voice.toggleMute(); }
}
