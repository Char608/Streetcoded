// js/game.js — Main game controller
// ============================================================
// Connects to server, runs game loop, handles all game events
// ============================================================

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Resize canvas to window
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// ── GAME STATE ────────────────────────────────────────────
const Game = {
  socket: null,
  myId: null,
  roomId: null,
  mode: 'ffa',
  localPlayer: null,     // local physics copy
  remotePlayers: {},     // id -> player data from server
  bullets: [],           // from server
  loot: [],
  zone: { x: 0, y: 0, w: 2400, h: 1800 },
  camera: { x: 0, y: 0 },
  kills: 0,
  dead: false,
  reloading: false,
  reloadTimer: 0,
  dashCooldown: 0,
  lastShotTime: 0,
  playerList: [],
  nearbyLoot: null,
  selectedMode: 'ffa',
};

// ── MODE SELECTOR ─────────────────────────────────────────
document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    Game.selectedMode = btn.dataset.mode;
  });
});

// ── JOIN GAME ─────────────────────────────────────────────
function joinGame() {
  const nameInput = document.getElementById('name-input');
  const name = nameInput.value.trim().toUpperCase() || 'PLAYER';
  const msg = document.getElementById('connecting-msg');
  msg.textContent = 'CONNECTING...';

  const socket = io({ transports: ['websocket'] });
  Game.socket = socket;

  socket.on('connect', () => {
    socket.emit('joinGame', { name, skin: selectedSkin, mode: Game.selectedMode });
  });

  socket.on('joined', (data) => {
    Game.myId = data.playerId;
    Game.roomId = data.roomId;
    Game.mode = data.mode;
    Game.loot = data.loot;
    Game.zone = data.zone;
    MAP.walls = data.walls;

    // Set up local player
    const me = data.players[data.playerId];
    if (me) {
      Game.localPlayer = {
        x: me.x, y: me.y, angle: 0,
        hp: 150, shield: 0,
        weapon: { name: 'DEFAULT GUN', ammo: 30, maxAmmo: 30, fireRate: 125, reloadTime: 500, bulletSpeed: 12, spread: 0.04 },
        inventory: [null, null],
        skin: selectedSkin,
        name,
        dashCooldown: 0,
        golden: false,
        speed: 3.2,
      };
    }

    // Init systems
    Input.init();
    Chat.init(socket);
    Voice.init(socket);

    // Switch screens
    document.getElementById('title-screen').classList.remove('active');
    document.getElementById('game-screen').classList.add('active');
    document.getElementById('mode-badge').textContent = { ffa: 'FREE FOR ALL', br: 'BATTLE ROYALE', zone: 'ZONE CONTROL' }[data.mode] || data.mode;

    updateHUDAll();
    requestAnimationFrame(gameLoop);
    msg.textContent = '';
  });

  socket.on('connect_error', () => {
    msg.textContent = 'CONNECTION FAILED. RETRYING...';
  });

  // ── Server events ──

  socket.on('gameState', (state) => {
    Game.remotePlayers = state.players;
    Game.bullets = state.bullets;
    if (state.zone) Game.zone = state.zone;
    // Update remote player data but don't overwrite local position
    if (state.players[Game.myId] && Game.localPlayer) {
      const me = state.players[Game.myId];
      Game.localPlayer.hp = me.hp;
      // Don't update x/y (we use client-side prediction)
    }
  });

  socket.on('hitSelf', ({ hp, shield }) => {
    if (Game.localPlayer) {
      Game.localPlayer.hp = Math.max(0, hp);
      Game.localPlayer.shield = Math.max(0, shield);
    }
    updateHUDAll();
    // Flash red if hit
    canvas.style.filter = 'brightness(2)';
    setTimeout(() => canvas.style.filter = '', 80);
  });

  socket.on('ammoUpdate', ({ ammo, maxAmmo }) => {
    if (Game.localPlayer) {
      Game.localPlayer.weapon.ammo = ammo;
      Game.localPlayer.weapon.maxAmmo = maxAmmo;
    }
    document.getElementById('ammo-cur').textContent = ammo;
    document.getElementById('ammo-max').textContent = maxAmmo;
  });

  socket.on('reloadDone', ({ ammo }) => {
    if (Game.localPlayer) Game.localPlayer.weapon.ammo = ammo;
    Game.reloading = false;
    document.getElementById('reload-bar-wrap').style.display = 'none';
    document.getElementById('ammo-cur').textContent = ammo;
    Renderer.spawnParticles(Game.localPlayer.x, Game.localPlayer.y, '#ffcc00', 4, Game.camera);
  });

  socket.on('inventoryUpdate', ({ weapon, inventory }) => {
    if (Game.localPlayer) {
      Game.localPlayer.weapon = weapon;
      Game.localPlayer.inventory = inventory;
    }
    updateInventoryHUD();
    updateAmmoHUD();
  });

  socket.on('lootUpdate', (loot) => {
    Game.loot = loot;
  });

  socket.on('zoneUpdate', (zone) => {
    Game.zone = zone;
  });

  socket.on('playerKilled', ({ victimId, victimName, killerName }) => {
    if (victimId === Game.myId) {
      handleDeath();
    } else {
      if (killerName === Game.localPlayer?.name) {
        Game.kills++;
        document.getElementById('kill-count').textContent = Game.kills;
        Renderer.spawnParticles(Game.remotePlayers[victimId]?.x || 0, Game.remotePlayers[victimId]?.y || 0, '#ffcc00', 12, Game.camera);
      }
    }
    addKillFeedEntry(`${killerName} → ${victimName}`);
  });

  socket.on('respawned', (spawn) => {
    if (Game.localPlayer) {
      Game.localPlayer.x = spawn.x;
      Game.localPlayer.y = spawn.y;
      Game.localPlayer.hp = 150;
      Game.localPlayer.shield = 0;
      Game.dead = false;
    }
    document.getElementById('death-overlay').style.display = 'none';
    updateHUDAll();
  });

  socket.on('goldenTransform', ({ hero }) => {
    if (Game.localPlayer) Game.localPlayer.golden = hero;
    const flash = document.getElementById('golden-flash');
    if (flash) { flash.classList.add('active'); setTimeout(() => flash.classList.remove('active'), 700); }
    Chat.addSystemMessage(`You found a GOLDEN ITEM! You are now ${hero.toUpperCase()}!`);
  });

  socket.on('goldenReverted', () => {
    if (Game.localPlayer) Game.localPlayer.golden = false;
    Chat.addSystemMessage('Golden transformation ended.');
  });

  socket.on('announcement', ({ text }) => {
    const el = document.getElementById('announcement');
    el.textContent = text;
    setTimeout(() => el.textContent = '', 4000);
  });

  socket.on('playerJoined', ({ id, name }) => {
    Chat.addSystemMessage(`${name} joined the match.`);
  });

  socket.on('playerLeft', ({ id, name }) => {
    Chat.addSystemMessage(`${name} left the match.`);
    delete Game.remotePlayers[id];
  });

  socket.on('playerList', (list) => {
    Game.playerList = list;
    if (escMenuOpen) updateEscPlayerList();
  });
}

// ── DEATH HANDLING ────────────────────────────────────────
function handleDeath() {
  Game.dead = true;
  const overlay = document.getElementById('death-overlay');
  overlay.style.display = 'flex';
  const msg = document.getElementById('death-msg');
  const timerEl = document.getElementById('respawn-timer');

  if (Game.mode === 'ffa') {
    msg.textContent = 'Respawning in...';
    let t = 3;
    timerEl.textContent = t;
    const iv = setInterval(() => {
      t--;
      timerEl.textContent = t;
      if (t <= 0) { clearInterval(iv); timerEl.textContent = ''; }
    }, 1000);
  } else {
    msg.textContent = 'You are eliminated.';
    timerEl.textContent = '';
  }
}

function leaveGame() {
  if (Game.socket) Game.socket.disconnect();
  document.getElementById('game-screen').classList.remove('active');
  document.getElementById('death-overlay').style.display = 'none';
  document.getElementById('esc-menu').style.display = 'none';
  document.getElementById('title-screen').classList.add('active');
  Game.dead = false;
  Game.kills = 0;
}

// ── GAME ACTIONS ──────────────────────────────────────────
Game.reload = function() {
  if (Game.reloading || !Game.localPlayer) return;
  const w = Game.localPlayer.weapon;
  if (w.ammo === w.maxAmmo) return;
  Game.reloading = true;
  Game.socket.emit('reload');

  // Visual reload bar
  const wrap = document.getElementById('reload-bar-wrap');
  const fill = document.getElementById('reload-bar-fill');
  wrap.style.display = 'block';
  fill.style.width = '0%';
  fill.style.transition = `width ${w.reloadTime}ms linear`;
  requestAnimationFrame(() => { fill.style.width = '100%'; });
};

Game.useItem = function() {
  if (!Game.socket) return;
  Game.socket.emit('useItem');
  Renderer.spawnParticles(Game.localPlayer.x, Game.localPlayer.y, '#44ff88', 8, Game.camera);
};

Game.pickupNearby = function() {
  if (!Game.nearbyLoot || !Game.socket) return;
  Game.socket.emit('pickupLoot', { lootId: Game.nearbyLoot.id });
  Game.nearbyLoot = null;
  document.getElementById('pickup-hint').style.display = 'none';
};

Game.dropItem = function() {
  if (!Game.socket) return;
  Game.socket.emit('dropItem');
};

// ── GAME LOOP ─────────────────────────────────────────────
let lastTime = 0;
function gameLoop(ts) {
  const dt = ts - lastTime;
  lastTime = ts;
  update(dt);
  draw();
  requestAnimationFrame(gameLoop);
}

function update(dt) {
  if (!Game.localPlayer || Game.dead) return;
  const p = Game.localPlayer;
  const keys = Input.keys;

  // Movement
  let mx = 0, my = 0;
  if (keys['KeyA'] || keys['ArrowLeft'])  mx -= 1;
  if (keys['KeyD'] || keys['ArrowRight']) mx += 1;
  if (keys['KeyW'] || keys['ArrowUp'])    my -= 1;
  if (keys['KeyS'] || keys['ArrowDown'])  my += 1;

  const len = Math.sqrt(mx * mx + my * my) || 1;
  let speed = p.speed;

  // Dash
  if ((keys['ShiftLeft'] || keys['ShiftRight']) && p.dashCooldown <= 0 && (mx || my)) {
    speed *= 8;
    p.dashCooldown = 2000;
    Renderer.spawnParticles(p.x, p.y, SKINS[p.skin].color, 6, Game.camera);
    document.getElementById('dash-hud').classList.add('cooldown');
    document.getElementById('dash-hud').textContent = 'DASH 2.0s';
  }

  if (p.dashCooldown > 0) {
    p.dashCooldown -= dt;
    if (p.dashCooldown <= 0) {
      document.getElementById('dash-hud').classList.remove('cooldown');
      document.getElementById('dash-hud').textContent = 'SHIFT · DASH';
    } else {
      document.getElementById('dash-hud').textContent = `DASH ${(p.dashCooldown / 1000).toFixed(1)}s`;
    }
  }

  p.x += (mx / len) * speed;
  p.y += (my / len) * speed;

  // Wall collision (client-side prediction using local wall data)
  resolveWalls(p);

  // Aim
  const worldMx = Input.mouse.x + Game.camera.x;
  const worldMy = Input.mouse.y + Game.camera.y;
  p.angle = Math.atan2(worldMy - p.y, worldMx - p.x);

  // Shoot
  if (Input.mouse.down && !Input.chatFocused) {
    const now = Date.now();
    const w = p.weapon;
    if (now - Game.lastShotTime > w.fireRate && !Game.reloading && w.ammo > 0) {
      Game.lastShotTime = now;
      Game.socket.emit('shoot', {
        x: p.x, y: p.y, angle: p.angle,
        bulletColor: SKINS[p.skin].bullet,
      });
    }
  }

  // Send position to server (20 times/sec handled by server tick)
  Game.socket.emit('playerUpdate', { x: p.x, y: p.y, angle: p.angle });

  // Camera
  Game.camera.x = Math.max(0, Math.min(MAP.WORLD_W - canvas.width, p.x - canvas.width / 2));
  Game.camera.y = Math.max(0, Math.min(MAP.WORLD_H - canvas.height, p.y - canvas.height / 2));

  // Nearby loot check
  Game.nearbyLoot = null;
  Game.loot.forEach(l => {
    const dx = l.x - p.x, dy = l.y - p.y;
    if (Math.sqrt(dx * dx + dy * dy) < 45) Game.nearbyLoot = l;
  });
  const hint = document.getElementById('pickup-hint');
  if (Game.nearbyLoot) {
    hint.style.display = 'block';
    hint.textContent = `[F] Pick up ${Game.nearbyLoot.type.toUpperCase()}`;
  } else {
    hint.style.display = 'none';
  }

  // Zone danger indicator
  const z = Game.zone;
  const outsideZone = p.x < z.x || p.x > z.x + z.w || p.y < z.y || p.y > z.y + z.h;
  document.getElementById('zone-warning').classList.toggle('danger', outsideZone && Game.mode === 'br');

  // Particles update
  Renderer.updateParticles();

  // Health bar
  updateHealthHUD();
}

// Client-side wall collision (fast local prediction)
function resolveWalls(p) {
  const hw = 11, hh = 11;
  const worldW = MAP.WORLD_W, worldH = MAP.WORLD_H;
  p.x = Math.max(hw + 30, Math.min(worldW - hw - 30, p.x));
  p.y = Math.max(hh + 30, Math.min(worldH - hh - 30, p.y));
  for (const w of MAP.walls) {
    if (p.x - hw < w.x + w.w && p.x + hw > w.x &&
        p.y - hh < w.y + w.h && p.y + hh > w.y) {
      const oL = (p.x + hw) - w.x;
      const oR = (w.x + w.w) - (p.x - hw);
      const oT = (p.y + hh) - w.y;
      const oB = (w.y + w.h) - (p.y - hh);
      const minO = Math.min(oL, oR, oT, oB);
      if (minO === oL) p.x = w.x - hw;
      else if (minO === oR) p.x = w.x + w.w + hw;
      else if (minO === oT) p.y = w.y - hh;
      else p.y = w.y + w.h + hh;
    }
  }
}

// ── DRAW ──────────────────────────────────────────────────
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Map
  MAP.draw(ctx, Game.camera);

  // Loot
  MAP.drawLoot(ctx, Game.camera, Game.loot);

  // Zone (only in BR — subtle in FFA)
  if (Game.mode === 'br') {
    MAP.drawZone(ctx, Game.camera, Game.zone);
    // Re-draw map on top of zone overlay for inside area
    // (zone overlay is semi-transparent so map shows through)
  }

  // Remote players
  Object.entries(Game.remotePlayers).forEach(([id, p]) => {
    if (id !== Game.myId && !p.dead) {
      Renderer.drawPlayer(ctx, p, false, Game.camera);
    }
  });

  // Local player
  if (Game.localPlayer && !Game.dead) {
    Renderer.drawPlayer(ctx, {
      ...Game.localPlayer,
      name: Game.localPlayer.name,
    }, true, Game.camera);
  }

  // Bullets
  Renderer.drawBullets(ctx, Game.bullets, Game.camera);

  // Particles
  Renderer.drawParticles(ctx, Game.camera);

  // Crosshair
  Renderer.drawCrosshair(ctx, Input.mouse.x, Input.mouse.y);
}

// ── HUD HELPERS ───────────────────────────────────────────
function updateHUDAll() {
  updateHealthHUD();
  updateAmmoHUD();
  updateInventoryHUD();
}

function updateHealthHUD() {
  if (!Game.localPlayer) return;
  const p = Game.localPlayer;
  document.getElementById('health-fill').style.width = Math.max(0, (p.hp / 150) * 100) + '%';
  document.getElementById('shield-fill').style.width = Math.max(0, (p.shield / 25) * 100) + '%';
}

function updateAmmoHUD() {
  if (!Game.localPlayer) return;
  const w = Game.localPlayer.weapon;
  document.getElementById('ammo-cur').textContent = w.ammo === 999 ? '∞' : w.ammo;
  document.getElementById('ammo-max').textContent = w.maxAmmo === 999 ? '∞' : w.maxAmmo;
  document.getElementById('gun-name-hud').textContent = w.name || 'DEFAULT GUN';
}

function updateInventoryHUD() {
  if (!Game.localPlayer) return;
  const slots = document.getElementById('inventory-slots');
  const inv = Game.localPlayer.inventory;
  const colors = { health: '#44dd66', shield: '#4488ff', shotgun: '#ffaa44', bounce: '#44ffcc' };
  const labels = { health: 'HP', shield: 'SH', shotgun: 'SG', bounce: 'BG' };
  slots.innerHTML = '';
  inv.forEach((item, i) => {
    const div = document.createElement('div');
    div.className = 'inv-slot' + (item ? ' has-item' : '');
    if (item) {
      div.style.background = `rgba(0,0,0,0.7)`;
      div.style.borderColor = colors[item];
      div.style.color = colors[item];
      div.textContent = labels[item] || '?';
    }
    slots.appendChild(div);
  });
}

function addKillFeedEntry(text) {
  const feed = document.getElementById('kill-feed');
  const div = document.createElement('div');
  div.className = 'kill-entry';
  div.textContent = text;
  feed.appendChild(div);
  setTimeout(() => div.remove(), 3000);
}

// Golden flash div (inject into game screen)
const gf = document.createElement('div');
gf.id = 'golden-flash';
document.getElementById('game-screen').appendChild(gf);
