// js/map.js — Map drawing
const MAP = {
  WORLD_W: 2400,
  WORLD_H: 1800,
  walls: [],   // received from server on join

  draw(ctx, camera) {
    const { x: cx, y: cy } = camera;
    const sw = canvas.width, sh = canvas.height;

    // Background (asphalt)
    ctx.fillStyle = '#1c1c14';
    ctx.fillRect(0, 0, sw, sh);

    // Road grid
    ctx.strokeStyle = '#242418';
    ctx.lineWidth = 1;
    const gridSize = 120;
    const startGx = Math.floor(cx / gridSize) * gridSize - cx;
    const startGy = Math.floor(cy / gridSize) * gridSize - cy;
    for (let gx = startGx; gx < sw; gx += gridSize) {
      ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, sh); ctx.stroke();
    }
    for (let gy = startGy; gy < sh; gy += gridSize) {
      ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(sw, gy); ctx.stroke();
    }

    // Road center lines (dashed yellow)
    ctx.setLineDash([20, 20]);
    ctx.strokeStyle = 'rgba(80,70,0,0.3)';
    ctx.lineWidth = 1;
    for (let gx = startGx + gridSize/2; gx < sw; gx += gridSize) {
      ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, sh); ctx.stroke();
    }
    for (let gy = startGy + gridSize/2; gy < sh; gy += gridSize) {
      ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(sw, gy); ctx.stroke();
    }
    ctx.setLineDash([]);

    // Walls / buildings
    this.walls.forEach(w => {
      const sx = w.x - cx, sy = w.y - cy;
      // Skip if off screen
      if (sx > sw || sy > sh || sx + w.w < 0 || sy + w.h < 0) return;

      // Building body
      ctx.fillStyle = '#2e2c20';
      ctx.fillRect(sx, sy, w.w, w.h);

      // Facade detail - darker inner rect
      if (w.w > 40 && w.h > 40) {
        ctx.fillStyle = '#28261c';
        ctx.fillRect(sx + 3, sy + 3, w.w - 6, w.h - 6);

        // Windows
        ctx.fillStyle = '#3a3620';
        const winCols = Math.floor((w.w - 10) / 18);
        const winRows = Math.floor((w.h - 10) / 18);
        for (let wr = 0; wr < winRows; wr++) {
          for (let wc = 0; wc < winCols; wc++) {
            const wx2 = sx + 8 + wc * 18;
            const wy = sy + 8 + wr * 18;
            // Random lit windows
            const seed = (w.x + w.y + wr * 100 + wc) % 7;
            ctx.fillStyle = seed < 3 ? 'rgba(255,220,100,0.15)' : '#28261c';
            ctx.fillRect(wx2, wy, 10, 10);
          }
        }
      }

      // Roof highlight
      ctx.fillStyle = 'rgba(255,255,255,0.04)';
      ctx.fillRect(sx, sy, w.w, 3);

      // Left shadow
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.fillRect(sx + w.w - 4, sy, 4, w.h);
      ctx.fillRect(sx, sy + w.h - 4, w.w, 4);
    });
  },

  drawZone(ctx, camera, zone) {
    const { x: cx, y: cy } = camera;
    const zsx = zone.x - cx, zsy = zone.y - cy;

    // Darken outside zone
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    // Cut out inside zone (bright)
    ctx.clearRect(zsx, zsy, zone.w, zone.h);
    // Re-draw map inside (handled by draw order: map drawn first, zone overlay after)

    // Zone border (police barricade style)
    ctx.strokeStyle = '#4488ff';
    ctx.lineWidth = 3;
    ctx.setLineDash([10, 6]);
    ctx.strokeRect(zsx, zsy, zone.w, zone.h);
    ctx.setLineDash([]);

    // Animated police lights along border
    const time = Date.now() / 200;
    const spacing = 60;
    const totalPerimeter = 2 * (zone.w + zone.h);
    const numLights = Math.floor(totalPerimeter / spacing);
    for (let i = 0; i < numLights; i++) {
      const t = (i / numLights + time * 0.05) % 1;
      let lx, ly;
      if (t < zone.w / totalPerimeter) {
        lx = zsx + t * totalPerimeter;
        ly = zsy;
      } else if (t < (zone.w + zone.h) / totalPerimeter) {
        lx = zsx + zone.w;
        ly = zsy + (t * totalPerimeter - zone.w);
      } else if (t < (2 * zone.w + zone.h) / totalPerimeter) {
        lx = zsx + zone.w - (t * totalPerimeter - zone.w - zone.h);
        ly = zsy + zone.h;
      } else {
        lx = zsx;
        ly = zsy + zone.h - (t * totalPerimeter - 2 * zone.w - zone.h);
      }
      const isRed = ((i + Math.floor(time)) % 2 === 0);
      ctx.fillStyle = isRed ? 'rgba(255,80,80,0.8)' : 'rgba(80,130,255,0.8)';
      ctx.beginPath();
      ctx.arc(lx, ly, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  },

  drawLoot(ctx, camera, lootItems) {
    const { x: cx, y: cy } = camera;
    const time = Date.now() / 500;
    lootItems.forEach(loot => {
      const sx = loot.x - cx, sy = loot.y - cy;
      if (sx < -20 || sx > canvas.width + 20 || sy < -20 || sy > canvas.height + 20) return;

      const pulse = Math.sin(time + loot.x) * 3;
      let color, label, bgColor;
      switch (loot.type) {
        case 'health':  color = '#44dd66'; label = 'HP'; bgColor = '#003300'; break;
        case 'shield':  color = '#4488ff'; label = 'SH'; bgColor = '#000033'; break;
        case 'shotgun': color = '#ffaa44'; label = 'SG'; bgColor = '#332000'; break;
        case 'bounce':  color = '#44ffcc'; label = 'BG'; bgColor = '#003322'; break;
        case 'golden':  color = '#ffdd00'; label = '★'; bgColor = '#332200'; break;
        default: return;
      }

      ctx.save();
      // Glow
      ctx.shadowColor = color;
      ctx.shadowBlur = 10 + pulse;

      // Box
      ctx.fillStyle = bgColor;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      const size = loot.type === 'golden' ? 18 : 14;
      ctx.fillRect(sx - size/2, sy - size/2, size, size);
      ctx.strokeRect(sx - size/2, sy - size/2, size, size);

      // Label
      ctx.shadowBlur = 0;
      ctx.fillStyle = color;
      ctx.font = loot.type === 'golden' ? `bold 14px monospace` : `bold 9px monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, sx, sy);

      ctx.restore();
    });
  },
};
