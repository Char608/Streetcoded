// js/renderer.js — Player and bullet rendering
const Renderer = {
  particles: [],

  spawnParticles(x, y, color, count, camera) {
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      const spd = 1 + Math.random() * 3;
      this.particles.push({
        x, y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        life: 20 + Math.random() * 20,
        maxLife: 40,
        color,
        size: 2 + Math.random() * 3,
      });
    }
  },

  updateParticles() {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx; p.y += p.vy;
      p.vx *= 0.88; p.vy *= 0.88;
      p.life--;
      if (p.life <= 0) this.particles.splice(i, 1);
    }
  },

  drawParticles(ctx, camera) {
    const { x: cx, y: cy } = camera;
    this.particles.forEach(p => {
      ctx.globalAlpha = p.life / p.maxLife;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x - cx, p.y - cy, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  },

  drawBullets(ctx, bullets, camera) {
    const { x: cx, y: cy } = camera;
    bullets.forEach(b => {
      const sx = b.x - cx, sy = b.y - cy;
      ctx.save();
      ctx.fillStyle = b.color || '#ffffff';
      ctx.shadowColor = b.color || '#ffffff';
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(sx, sy, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  },

  drawPlayer(ctx, player, isLocalPlayer, camera) {
    const { x: cx, y: cy } = camera;
    const sx = player.x - cx, sy = player.y - cy;

    // Skip if off screen
    if (sx < -40 || sx > canvas.width + 40 || sy < -40 || sy > canvas.height + 40) return;

    const skin = SKINS[player.skin] || SKINS[0];
    const golden = player.golden;

    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(player.angle + Math.PI / 2);

    if (golden) {
      // Golden glow aura
      ctx.shadowColor = '#ffcc00';
      ctx.shadowBlur = 20;
    }

    // Body shadow
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath();
    ctx.ellipse(2, 8, 10, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Golden: special hero body
    if (golden === 'plasma') {
      this._drawPlasmaCore(ctx, skin);
    } else if (golden === 'phantom') {
      this._drawWebPhantom(ctx, skin);
    } else if (golden === 'blade') {
      this._drawBladeRanger(ctx, skin);
    } else {
      this._drawHoodie(ctx, skin);
    }

    // Gun barrel
    ctx.fillStyle = golden ? '#ffcc00' : '#444';
    ctx.fillRect(5, -3, 18, 5);
    if (golden) {
      ctx.fillStyle = 'rgba(255,204,0,0.4)';
      ctx.fillRect(5, -5, 20, 9);
    }

    ctx.restore();

    // Health bar
    const hpPct = Math.max(0, player.hp / 150);
    const barW = 32;
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(sx - barW / 2, sy - 26, barW, 4);
    ctx.fillStyle = hpPct > 0.5 ? '#44dd66' : hpPct > 0.25 ? '#ffcc00' : '#ee3333';
    ctx.fillRect(sx - barW / 2, sy - 26, barW * hpPct, 4);

    // Shield bar (above health)
    if (player.shield > 0) {
      const shPct = player.shield / 25;
      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      ctx.fillRect(sx - barW / 2, sy - 32, barW, 3);
      ctx.fillStyle = '#4488ff';
      ctx.fillRect(sx - barW / 2, sy - 32, barW * shPct, 3);
    }

    // Name tag
    ctx.font = '9px monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = isLocalPlayer ? '#ffcc00' : (golden ? '#ffdd55' : '#cccccc');
    ctx.fillText(player.name, sx, sy - 36);
  },

  _drawHoodie(ctx, skin) {
    // Body
    ctx.fillStyle = skin.color;
    ctx.beginPath();
    ctx.roundRect(-10, -10, 20, 22, [10, 10, 5, 5]);
    ctx.fill();
    // Hood shadow
    ctx.fillStyle = skin.hoodie;
    ctx.beginPath();
    ctx.arc(0, -7, 9, 0, Math.PI * 2);
    ctx.fill();
    // Face
    ctx.fillStyle = '#c8a07a';
    ctx.beginPath();
    ctx.arc(0, -7, 6, 0, Math.PI * 2);
    ctx.fill();
    // Eyes
    ctx.fillStyle = '#2a2a2a';
    ctx.fillRect(-3.5, -9.5, 2.5, 2.5);
    ctx.fillRect(1, -9.5, 2.5, 2.5);
  },

  _drawPlasmaCore(ctx, skin) {
    // Armored energy suit
    ctx.fillStyle = '#1a1a33';
    ctx.beginPath();
    ctx.roundRect(-11, -12, 22, 24, 6);
    ctx.fill();
    // Energy chest piece
    ctx.fillStyle = '#3355ff';
    ctx.beginPath();
    ctx.roundRect(-7, -5, 14, 12, 3);
    ctx.fill();
    // Visor
    ctx.fillStyle = '#00ffcc';
    ctx.beginPath();
    ctx.roundRect(-6, -11, 12, 6, 3);
    ctx.fill();
    // Glow
    ctx.fillStyle = 'rgba(0,255,200,0.2)';
    ctx.beginPath();
    ctx.arc(0, -8, 12, 0, Math.PI * 2);
    ctx.fill();
  },

  _drawWebPhantom(ctx, skin) {
    // Dark body
    ctx.fillStyle = '#111122';
    ctx.beginPath();
    ctx.roundRect(-10, -12, 20, 24, 8);
    ctx.fill();
    // Web pattern lines
    ctx.strokeStyle = '#8844ff';
    ctx.lineWidth = 1;
    for (let i = -8; i <= 8; i += 5) {
      ctx.beginPath();
      ctx.moveTo(i, -12); ctx.lineTo(i, 12);
      ctx.stroke();
    }
    // Mask
    ctx.fillStyle = '#330066';
    ctx.beginPath();
    ctx.arc(0, -7, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#8844ff';
    ctx.lineWidth = 1;
    ctx.stroke();
    // Web eyes
    ctx.fillStyle = '#cc88ff';
    ctx.beginPath();
    ctx.ellipse(-3, -8, 3, 2, -0.3, 0, Math.PI * 2);
    ctx.ellipse(3, -8, 3, 2, 0.3, 0, Math.PI * 2);
    ctx.fill();
  },

  _drawBladeRanger(ctx, skin) {
    // Military vest
    ctx.fillStyle = '#3a3a1a';
    ctx.beginPath();
    ctx.roundRect(-11, -10, 22, 22, 4);
    ctx.fill();
    // Armor plates
    ctx.fillStyle = '#555530';
    ctx.fillRect(-8, -5, 8, 10);
    ctx.fillRect(2, -5, 8, 10);
    // Helmet
    ctx.fillStyle = '#2a2a10';
    ctx.beginPath();
    ctx.arc(0, -8, 9, 0, Math.PI * 2);
    ctx.fill();
    // Visor
    ctx.fillStyle = '#aaff44';
    ctx.fillRect(-6, -11, 12, 5);
  },

  drawCrosshair(ctx, mx, my) {
    const size = 10, gap = 4;
    ctx.strokeStyle = 'rgba(255,255,255,0.8)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(mx - size - gap, my); ctx.lineTo(mx - gap, my);
    ctx.moveTo(mx + gap, my);       ctx.lineTo(mx + size + gap, my);
    ctx.moveTo(mx, my - size - gap); ctx.lineTo(mx, my - gap);
    ctx.moveTo(mx, my + gap);       ctx.lineTo(mx, my + size + gap);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    ctx.arc(mx, my, 6, 0, Math.PI * 2);
    ctx.stroke();
  },
};
