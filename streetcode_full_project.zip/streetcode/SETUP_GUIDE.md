# STREETCODE — Setup Guide
## Complete Step-by-Step for Beginners (Zero Coding Experience)

---

## WHAT YOU NEED (ALL FREE)
1. A GitHub account — github.com
2. A Railway account — railway.app
3. GitHub Desktop — desktop.github.com (easier than command line)
4. Node.js — nodejs.org (only needed for local testing)

---

## PART 1: SET UP YOUR FILES

Your project folder called `streetcode` should look like this:
```
streetcode/
├── package.json
├── railway.json
├── .gitignore
├── server/
│   └── index.js
└── public/
    └── index.html
```

---

## PART 2: TEST LOCALLY (ON YOUR OWN COMPUTER)

### Step 1: Install Node.js
- Go to nodejs.org
- Click the green "LTS" button to download
- Install it (click Next → Next → Finish)

### Step 2: Open your project folder
- Right-click the `streetcode` folder
- Select "Open in Terminal" (Windows) or "New Terminal at Folder" (Mac)

### Step 3: Install packages
Type this and press Enter:
```
npm install
```
Wait for it to finish (you'll see a `node_modules` folder appear)

### Step 4: Start the server
```
npm start
```
You'll see: `STREETCODE running on :3000`

### Step 5: Play it
- Open your browser
- Go to: `http://localhost:3000`
- Open a second browser tab to the same address
- You can now play against yourself to test multiplayer!

To stop the server: press `Ctrl + C` in the terminal

---

## PART 3: PUT IT ON GITHUB

### Step 1: Create a GitHub account
- Go to github.com
- Sign up for free

### Step 2: Download GitHub Desktop
- Go to desktop.github.com
- Download and install it
- Sign in with your GitHub account

### Step 3: Create a new repository
- In GitHub Desktop, click "File" → "New Repository"
- Name it: `streetcode`
- Choose where to save it (pick your `streetcode` folder)
- Click "Create Repository"

### Step 4: Copy your files in
- Copy all your `streetcode` files into the folder GitHub Desktop created

### Step 5: Upload (push) to GitHub
- In GitHub Desktop, you'll see your files listed on the left
- Type a message in the "Summary" box at the bottom left: `Initial commit`
- Click "Commit to main"
- Click "Publish repository" (or "Push origin")
- Make sure "Keep this code private" is UNCHECKED (Railway needs to see it)
- Click "Publish Repository"

Your code is now on GitHub!

---

## PART 4: DEPLOY TO RAILWAY (GO LIVE ONLINE)

### Step 1: Create a Railway account
- Go to railway.app
- Click "Start a New Project"
- Sign up with your GitHub account (recommended — it connects automatically)

### Step 2: Create new project
- Click "New Project"
- Click "Deploy from GitHub repo"
- Find and select your `streetcode` repository
- Click "Deploy Now"

### Step 3: Wait for deploy
- Railway will show a build log
- Wait for it to say "Deployment successful" (takes 1-3 minutes)

### Step 4: Get your URL
- Click on your deployment
- Click "Settings"
- Under "Domains", click "Generate Domain"
- You'll get a URL like: `streetcode-production.up.railway.app`

### Step 5: Share it!
- Send that URL to your friends
- Everyone can play at the same time on any device with a browser
- Chromebooks work great

---

## CONTROLS (IN GAME)

| Key | Action |
|-----|--------|
| WASD / Arrow Keys | Move |
| Mouse | Aim |
| Left Click | Shoot |
| R | Reload |
| Shift | Dash (2 second cooldown) |
| F | Pick up loot |
| E | Use healing item |
| G | Drop item |
| T | Open chat (type your message, press Enter) |
| ESC | Player list / mute / DM menu |

---

## GAME FEATURES

### Weapons You Can Find
- **Default Gun** — 30 shots, fast fire rate, balanced
- **Shotgun** — 5 shots, deadly up close, wide spread
- **Bounce Gun** — bullets ricochet off walls (rare)
- **Golden Item ★** — transforms you into a special hero for 45 seconds!

### Golden Heroes (very rare loot)
- **Plasma Core** — unlimited energy shots, heals over time
- **Web Phantom** — web attacks that slow enemies, zip dash ability
- **Blade Ranger** — burst of 5 blades that pass through enemies

### Healing Items
- **HP pack** — heals 25 HP (hold up to 3)
- **Shield pack** — adds 25 shield (holds 1)
- Press **E** to use items from your inventory

### Game Modes
- **FFA** — everyone vs everyone, respawn after death
- **Battle Royale** — no respawns, zone shrinks (police wall closes in)
- **Zone Control** — capture zones for points

### Chat System
- Press **T** to type in global chat
- Press **ESC** to open player list
- From ESC menu you can: Mute players, Send direct messages (DMs)
- Chat shows at bottom left, toggle with **T**

### Voice Chat
- Click **MIC OFF** button (top left) to enable voice chat
- Your browser will ask for microphone permission — click Allow
- You'll hear other players automatically
- Mute specific players from the ESC menu

---

## TROUBLESHOOTING

**"npm install" fails?**
→ Make sure Node.js is installed. Restart your terminal after installing.

**Game loads but I can't move?**
→ Click on the game canvas first (it needs focus)

**Can't hear other players in voice chat?**
→ Make sure you clicked "Allow" when the browser asked for microphone access
→ Both players need to have MIC ON clicked

**Railway deploy fails?**
→ Make sure your package.json has the correct "start" script
→ Make sure all files are committed and pushed to GitHub

**Game is laggy on Chromebook?**
→ Close other tabs
→ Use Chrome browser (fastest)
→ The game is already optimized for Chromebook — if still slow, close other apps

---

## MAKING CHANGES LATER

1. Edit your files in any text editor (Notepad, VSCode, etc.)
2. Save the files
3. In GitHub Desktop: write a commit message → Commit → Push
4. Railway automatically re-deploys in about 1 minute!

---

*STREETCODE v1.0 — Built with Node.js + Socket.io + HTML5 Canvas*
